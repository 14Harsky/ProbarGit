package com.example.MiPrimeraWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiPrimeraWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiPrimeraWebApplication.class, args);
	}

}
